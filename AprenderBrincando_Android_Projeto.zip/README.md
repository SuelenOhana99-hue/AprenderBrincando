# Aprender Brincando — Android

Projeto Android que empacota a versão web local do aplicativo "Aprender Brincando – ODS 4".

## Como gerar o APK/AAB
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Use Build > Generate App Bundles or APKs.
4. Para Google Play, gere um Android App Bundle (.aab).

O arquivo HTML em `app/src/main/assets/` é a experiência educativa original.
